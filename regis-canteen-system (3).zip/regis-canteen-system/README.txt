Regis Marie College Canteen: Menu and Order Queue System

FOLDERS
  (this folder)   Web version + server.js (backend). Students: /  Staff: /staff  Admin: /admin
  flutter_app/    Flutter mobile app (Dart). Talks to the same server.

A. RUN LOCALLY (same Wi-Fi)
  1. Install Node.js. In this folder run:  node server.js
  2. Open the printed link on any phone on the same Wi-Fi.

B. PUT IT ONLINE (works on any Wi-Fi or mobile data)
  Example with Render.com (free tier available; it may sleep when idle):
  1. Upload this folder (without flutter_app if you like) to a GitHub repository.
  2. On Render: New > Web Service > connect the repo.
       Runtime: Node      Build command: (leave empty)      Start command: node server.js
  3. Under Environment, set STAFF_PIN and ADMIN_PIN to your own PINs. IMPORTANT: the
     defaults (1234 / 4321) are public in this README.
  4. Render gives you a link like https://regis-canteen.onrender.com
     Students open it on their phones; staff use /staff, admin uses /admin.
  Note: free hosts may reset data.json when the service restarts. For permanent data,
  use a persistent disk (set DATA_DIR to its path) or move to a database later.

C. FLUTTER APP
  1. Install Flutter (flutter.dev). In flutter_app/ run:   flutter create .
  2. Android: make sure android/app/src/main/AndroidManifest.xml has, above <application>:
       <uses-permission android:name="android.permission.INTERNET"/>
  3. Open lib/main.dart and set kBaseUrl to your online link (https).
  4. Run:  flutter pub get   then   flutter run     (APK:  flutter build apk)
  In the app, the menu (top right) has Staff sign-in and Admin sign-in.

D. USE MYSQL (recommended for real use)
  The server uses MySQL when DATABASE_URL (or DB_HOST) is set. Without it, it uses data.json.
  Tables are created automatically on first run (see schema.sql) and the sample menu is added.
  1. Make a MySQL database:
       - On your own PC: XAMPP / MySQL Workbench, then:  CREATE DATABASE canteen;
       - Or a hosted MySQL (Aiven, Railway, TiDB Cloud, a school/web host).
  2. In this folder run:  npm install
  3. Start with your database settings:
       DATABASE_URL="mysql://USER:PASSWORD@HOST:3306/canteen" node server.js
     or set DB_HOST, DB_PORT, DB_USER, DB_PASSWORD, DB_NAME.
     If your host requires SSL, also set DB_SSL=true.
     On Windows (PowerShell):
       $env:DATABASE_URL="mysql://root:@localhost:3306/canteen"; node server.js
  4. On Render (or any host), add the same values under Environment and set the
     build command to:  npm install     Start command:  node server.js
     Your data now stays even when the web service restarts.
  Times use Asia/Manila by default (change with TIMEZONE=...).
  Tested against MariaDB (MySQL-compatible); on MySQL 5.7+ / 8 it should behave the same.

E. INVENTORY, STAFF AND ADMIN (new)
  - Every menu item has Stock, Price and Cost. Stock goes down automatically when a student
    orders and comes back if the order is cancelled. At 0 the item shows "Sold out".
  - Students see how many are left. Orders larger than the stock are refused.
  - Staff page (/staff): Orders board + Inventory tab (stock, low-stock and sold-out alerts,
    "Mark sold out / available" button).
  - Admin page (/admin): Dashboard (sales today, profit today, sales still in progress,
    7-day sales chart, best sellers, stock alerts) and Menu & stock (edit stock, price, cost).
    Profit = selling price minus cost. Set the Cost of each item first (sample costs are guesses).
  - "Load sample data" on the dashboard fills the last 6 days with fake DEMO orders for
    presentations. "Remove sample data" deletes them. They never change your stock.
  - Customer names and costs are no longer sent to students' phones. Only staff/admin PIN holders get them.
  - Existing MySQL databases are upgraded automatically (new columns; old items start at stock 50, cost 0).
  - The Flutter app has the stock display, sold-out logic and stock editing. The sales dashboard is on the web admin page.

F. MENU PHOTOS (new)
  - Each menu item shows a picture on the student menu, cart, staff inventory and admin list.
  - Until you add a real photo, a food emoji picture is shown (chosen from the item name).
  - Admin page > Menu & stock > "Upload photo" on any item (from the phone gallery or camera).
    Photos are shrunk automatically to 480 px, saved in the database (MySQL or data.json),
    and cached by the phones. "Remove photo" goes back to the emoji.
  - Use your own photos of the canteen's food, or images you have the right to use.
  - The Flutter app displays the photos; uploading is done from the web Admin page.
