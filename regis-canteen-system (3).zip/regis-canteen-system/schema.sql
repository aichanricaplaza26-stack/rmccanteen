-- Regis Marie College Canteen: MySQL schema
-- server.js creates/updates these tables automatically; this file is for reference.
CREATE TABLE IF NOT EXISTS menu_items (
  id      VARCHAR(40)   NOT NULL PRIMARY KEY,
  name    VARCHAR(60)   NOT NULL,
  cat     VARCHAR(30)   NOT NULL,
  price   DECIMAL(10,2) NOT NULL,             -- selling price
  cost    DECIMAL(10,2) NOT NULL DEFAULT 0,   -- cost per piece (for profit)
  stock   INT           NOT NULL DEFAULT 50,  -- pieces left; 0 = automatically sold out
  is_on   TINYINT(1)    NOT NULL DEFAULT 1,   -- 0 = manually marked sold out
  ord     BIGINT        NOT NULL DEFAULT 0,
  image   MEDIUMTEXT    NULL,                 -- photo as a data URL (set from the Admin page)
  imgv    BIGINT        NOT NULL DEFAULT 0    -- photo version (0 = no photo)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS orders (
  id      VARCHAR(40)   NOT NULL PRIMARY KEY,
  t       BIGINT        NOT NULL,             -- order time (ms); queue number = rank by t per day
  day     VARCHAR(10)   NOT NULL,             -- YYYY-MM-DD (Asia/Manila)
  name    VARCHAR(60)   NOT NULL,
  total   DECIMAL(10,2) NOT NULL,
  status  VARCHAR(12)   NOT NULL DEFAULT 'pending',  -- pending, preparing, ready, done, cancelled
  INDEX idx_orders_day (day)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS order_items (
  order_id VARCHAR(40)  NOT NULL,
  item_id  VARCHAR(40)  NOT NULL,
  name     VARCHAR(60)  NOT NULL,             -- copied at order time
  price    DECIMAL(10,2) NOT NULL,            -- copied at order time
  cost     DECIMAL(10,2) NOT NULL DEFAULT 0,  -- copied at order time
  qty      INT          NOT NULL,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
) ENGINE=InnoDB;
