import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

// Put your deployed server link here (use https).
// Android emulator + server running on your PC: http://10.0.2.2:3000
const String kBaseUrl = 'https://YOUR-APP.onrender.com';

const flow = [
  ['pending', 'Waiting', 'preparing', 'Start'],
  ['preparing', 'Preparing', 'ready', 'Mark ready'],
  ['ready', 'Ready', 'done', 'Picked up'],
];
const labels = {
  'pending': 'Waiting',
  'preparing': 'Preparing',
  'ready': 'Ready',
  'done': 'Picked up',
  'cancelled': 'Cancelled',
};

String errMsg(Object e) => e.toString().replaceFirst('Exception: ', '');
void toast(BuildContext c, String m) =>
    ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m)));
String peso(num n) => '₱${n.toStringAsFixed(0)}';
String emojiFor(Map<String, dynamic> m) {
  final t = '${m['name']} ${m['cat']}'.toLowerCase();
  const table = [
    ['adobo|chicken', '🍗'], ['sisig|pork|bacon', '🥓'], ['tapa|beef|steak', '🥩'], ['hot ?dog', '🌭'],
    ['siomai|dumpling', '🥟'], ['fries', '🍟'], ['burger', '🍔'], ['pizza', '🍕'], ['pancit|noodle|mami', '🍜'],
    ['spaghetti|pasta', '🍝'], ['egg', '🍳'], ['cake|bibingka', '🍰'], ['coffee', '☕'], [r'\btea\b', '🧋'],
    ['buko', '🥥'], ['juice', '🧃'], ['water', '💧'], ['soda|cola|coke', '🥤'], ['sandwich', '🥪'], ['rice', '🍚'],
  ];
  for (final e in table) {
    if (RegExp(e[0]).hasMatch(t)) return e[1];
  }
  return '🍽️';
}

Widget itemImage(Map<String, dynamic> m, {double size = 56}) {
  final v = (m['imgv'] as num?) ?? 0;
  final fallback = Container(
    width: size,
    height: size,
    alignment: Alignment.center,
    decoration: BoxDecoration(color: const Color(0x221D4ED8), borderRadius: BorderRadius.circular(10)),
    child: Text(emojiFor(m), style: TextStyle(fontSize: size * 0.5)),
  );
  if (v == 0) return fallback;
  return ClipRRect(
    borderRadius: BorderRadius.circular(10),
    child: Image.network('$kBaseUrl/img/${Uri.encodeComponent(m['id'] as String)}?v=$v',
        width: size, height: size, fit: BoxFit.cover, errorBuilder: (_, __, ___) => fallback),
  );
}

String tno(int n) => 'A-${n.toString().padLeft(3, '0')}';

class Api {
  static String pin = '';
  static Future<dynamic> call(String path, {Map<String, dynamic>? body}) async {
    try {
      final uri = Uri.parse('$kBaseUrl$path');
      final headers = {'Content-Type': 'application/json', 'x-pin': pin};
      final res = body == null
          ? await http.get(uri, headers: headers)
          : await http.post(uri, headers: headers, body: jsonEncode(body));
      final data = jsonDecode(res.body);
      if (res.statusCode >= 400) {
        throw Exception((data is Map ? data['error'] : null) ?? 'Something went wrong');
      }
      return data;
    } catch (e) {
      if (e.toString().startsWith('Exception: ')) rethrow;
      throw Exception('Can’t reach the canteen server. Check your internet.');
    }
  }
}

class Store extends ChangeNotifier {
  List<Map<String, dynamic>> menu = [];
  List<Map<String, dynamic>> orders = [];
  List<String> my = [];
  Map<String, int> cart = {};
  bool loaded = false;
  String? error;
  Timer? _timer;

  Future<void> start() async {
    final p = await SharedPreferences.getInstance();
    my = p.getStringList('my') ?? [];
    await refresh();
    _timer ??= Timer.periodic(const Duration(seconds: 3), (_) => refresh());
  }

  Future<void> refresh() async {
    try {
      final j = await Api.call('/api/state?mine=${Uri.encodeComponent(my.join(","))}');
      menu = (j['menu'] as List).map((e) => Map<String, dynamic>.from(e)).toList();
      final os = (j['orders'] as List).map((e) => Map<String, dynamic>.from(e)).toList();
      os.sort((a, b) => (a['t'] as num).compareTo(b['t'] as num));
      for (var i = 0; i < os.length; i++) {
        os[i]['no'] = i + 1;
      }
      orders = os;
      error = null;
    } catch (e) {
      error = errMsg(e);
    }
    loaded = true;
    notifyListeners();
  }

  int get cartCount => cart.values.fold(0, (a, b) => a + b);
  num get cartTotal {
    num t = 0;
    for (final m in menu) {
      t += (m['price'] as num) * (cart[m['id']] ?? 0);
    }
    return t;
  }

  void add(String id) {
    cart[id] = (cart[id] ?? 0) + 1;
    notifyListeners();
  }

  void remove(String id) {
    final q = (cart[id] ?? 0) - 1;
    if (q <= 0) {
      cart.remove(id);
    } else {
      cart[id] = q;
    }
    notifyListeners();
  }

  Future<void> place(String name) async {
    final j = await Api.call('/api/orders', body: {
      'name': name,
      'items': [
        for (final e in cart.entries) {'id': e.key, 'qty': e.value}
      ],
    });
    my.add(j['id'] as String);
    final p = await SharedPreferences.getInstance();
    await p.setStringList('my', my);
    cart.clear();
    await refresh();
  }
}

final store = Store();

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  store.start();
  runApp(const CanteenApp());
}

class CanteenApp extends StatelessWidget {
  const CanteenApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Regis Marie College Canteen',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF17233B), secondary: const Color(0xFFFFC933)),
      ),
      home: const StudentHome(),
    );
  }
}

class StudentHome extends StatefulWidget {
  const StudentHome({super.key});
  @override
  State<StudentHome> createState() => _StudentHomeState();
}

class _StudentHomeState extends State<StudentHome> {
  int tab = 0;
  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) => Scaffold(
        appBar: AppBar(
          title: const Text('Regis Marie College Canteen', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
          actions: [
            PopupMenuButton<String>(
              onSelected: (v) => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => v == 'staff' ? const StaffPage() : const AdminPage())),
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'staff', child: Text('Staff sign-in')),
                PopupMenuItem(value: 'admin', child: Text('Admin sign-in')),
              ],
            ),
          ],
        ),
        body: !store.loaded
            ? const Center(child: CircularProgressIndicator())
            : Column(children: [
                if (store.error != null)
                  Container(
                    width: double.infinity,
                    color: Theme.of(context).colorScheme.errorContainer,
                    padding: const EdgeInsets.all(8),
                    child: Text(store.error!, textAlign: TextAlign.center),
                  ),
                Expanded(child: tab == 0 ? const MenuTab() : const QueueTab()),
              ]),
        floatingActionButton: tab == 0 && store.cartCount > 0
            ? FloatingActionButton.extended(
                icon: const Icon(Icons.shopping_cart),
                label: Text('View cart · ${store.cartCount} · ${peso(store.cartTotal)}'),
                onPressed: () async {
                  final ok = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => const CartPage()));
                  if (ok == true) setState(() => tab = 1);
                },
              )
            : null,
        bottomNavigationBar: NavigationBar(
          selectedIndex: tab,
          onDestinationSelected: (i) => setState(() => tab = i),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.restaurant_menu), label: 'Menu'),
            NavigationDestination(icon: Icon(Icons.confirmation_number), label: 'My queue'),
          ],
        ),
      ),
    );
  }
}

class MenuTab extends StatefulWidget {
  const MenuTab({super.key});
  @override
  State<MenuTab> createState() => _MenuTabState();
}

class _MenuTabState extends State<MenuTab> {
  String cat = 'All';
  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final cats = ['All', ...{for (final m in store.menu) m['cat'] as String}];
        final items = store.menu.where((m) => cat == 'All' || m['cat'] == cat).toList();
        return Column(children: [
          SizedBox(
            height: 56,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              children: [
                for (final c in cats)
                  Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ChoiceChip(label: Text(c), selected: c == cat, onSelected: (_) => setState(() => cat = c)),
                  ),
              ],
            ),
          ),
          Expanded(
            child: items.isEmpty
                ? const Center(child: Text('No items yet. Check back soon.'))
                : ListView.builder(
                    padding: const EdgeInsets.fromLTRB(12, 0, 12, 90),
                    itemCount: items.length,
                    itemBuilder: (_, i) {
                      final m = items[i];
                      final id = m['id'] as String;
                      final q = store.cart[id] ?? 0;
                      final stock = (m['stock'] as num?)?.toInt() ?? 0;
                      final on = m['on'] == 1 && stock > 0;
                      return Card(
                        child: ListTile(
                          leading: itemImage(m),
                          title: Text(m['name'] as String, style: const TextStyle(fontWeight: FontWeight.w700)),
                          subtitle: Text('${m['cat']} · ${peso(m['price'] as num)}${on ? ' · $stock left' : ''}'),
                          trailing: !on
                              ? const Chip(label: Text('Sold out'))
                              : q == 0
                                  ? FilledButton(onPressed: () => store.add(id), child: const Text('Add'))
                                  : Row(mainAxisSize: MainAxisSize.min, children: [
                                      IconButton(onPressed: () => store.remove(id), icon: const Icon(Icons.remove_circle_outline)),
                                      Text('$q', style: const TextStyle(fontWeight: FontWeight.w700)),
                                      IconButton(onPressed: q >= stock ? null : () => store.add(id), icon: const Icon(Icons.add_circle_outline)),
                                    ]),
                        ),
                      );
                    },
                  ),
          ),
        ]);
      },
    );
  }
}

class CartPage extends StatefulWidget {
  const CartPage({super.key});
  @override
  State<CartPage> createState() => _CartPageState();
}

class _CartPageState extends State<CartPage> {
  final name = TextEditingController();
  bool busy = false;

  Future<void> place() async {
    if (name.text.trim().isEmpty) {
      toast(context, 'Enter your name or student ID');
      return;
    }
    setState(() => busy = true);
    try {
      await store.place(name.text.trim());
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) {
        toast(context, errMsg(e));
        setState(() => busy = false);
      }
    }
  }

  @override
  void dispose() {
    name.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final lines = store.menu.where((m) => (store.cart[m['id']] ?? 0) > 0).toList();
        return Scaffold(
          appBar: AppBar(title: const Text('Your order')),
          body: ListView(padding: const EdgeInsets.all(12), children: [
            if (lines.isEmpty)
              const Padding(padding: EdgeInsets.all(24), child: Center(child: Text('Your cart is empty. Pick something from the menu.'))),
            for (final m in lines)
              Card(
                child: ListTile(
                  leading: itemImage(m, size: 44),
                  title: Text(m['name'] as String),
                  subtitle: Text('${peso(m['price'] as num)} each'),
                  trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                    IconButton(onPressed: () => store.remove(m['id'] as String), icon: const Icon(Icons.remove_circle_outline)),
                    Text('${store.cart[m['id']]}'),
                    IconButton(onPressed: () => store.add(m['id'] as String), icon: const Icon(Icons.add_circle_outline)),
                  ]),
                ),
              ),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    const Text('Total', style: TextStyle(fontWeight: FontWeight.w700)),
                    Text(peso(store.cartTotal), style: const TextStyle(fontWeight: FontWeight.w700)),
                  ]),
                  const SizedBox(height: 12),
                  TextField(
                    controller: name,
                    decoration: const InputDecoration(labelText: 'Name or student ID', border: OutlineInputBorder()),
                  ),
                  const SizedBox(height: 8),
                  const Text('Pay at the counter when you pick up.'),
                ]),
              ),
            ),
            FilledButton(
              onPressed: busy || lines.isEmpty ? null : place,
              child: Padding(padding: const EdgeInsets.all(8), child: Text(busy ? 'Placing order…' : 'Place order')),
            ),
          ]),
        );
      },
    );
  }
}

Widget stat(String label, String value) => Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(children: [
          Text(label, style: const TextStyle(fontSize: 12)),
          const SizedBox(height: 4),
          Text(value, textAlign: TextAlign.center, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
        ]),
      ),
    );

class QueueTab extends StatelessWidget {
  const QueueTab({super.key});
  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final active = store.orders.where((o) => o['status'] == 'pending' || o['status'] == 'preparing').toList();
        final ready = store.orders.where((o) => o['status'] == 'ready').map((o) => tno(o['no'] as int)).join(', ');
        final mine = store.orders.where((o) => store.my.contains(o['id'])).toList().reversed.toList();
        return ListView(padding: const EdgeInsets.all(12), children: [
          Row(children: [
            Expanded(child: stat('Ready for pickup', ready.isEmpty ? '–' : ready)),
            Expanded(child: stat('Orders in line', '${active.length}')),
          ]),
          if (mine.isEmpty)
            const Padding(padding: EdgeInsets.all(24), child: Center(child: Text('You have no orders today. Place one from the menu to get a queue number.'))),
          for (final o in mine) Ticket(order: o, ahead: active.where((x) => (x['t'] as num) < (o['t'] as num)).length),
        ]);
      },
    );
  }
}

class Ticket extends StatelessWidget {
  final Map<String, dynamic> order;
  final int ahead;
  const Ticket({super.key, required this.order, required this.ahead});
  @override
  Widget build(BuildContext context) {
    final st = order['status'] as String;
    final msg = st == 'pending'
        ? '$ahead order${ahead == 1 ? '' : 's'} ahead · about ${(ahead + 1) * 3} min'
        : st == 'preparing'
            ? 'Being prepared now'
            : st == 'ready'
                ? 'Ready! Show this number at the counter.'
                : st == 'done'
                    ? 'Picked up. Thank you!'
                    : 'Cancelled by the canteen.';
    final items = ((order['items'] as List?) ?? []).map((i) => '${i['qty']}× ${i['name']}').join(', ');
    return Card(
      color: const Color(0xFFFFC933),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text(tno(order['no'] as int), style: const TextStyle(fontSize: 44, fontWeight: FontWeight.w800, color: Color(0xFF2A2000))),
            Chip(label: Text(labels[st] ?? st)),
          ]),
          Text(msg, style: const TextStyle(fontWeight: FontWeight.w700, color: Color(0xFF2A2000))),
          const SizedBox(height: 4),
          Text('$items · ${peso((order['total'] as num?) ?? 0)}', style: const TextStyle(color: Color(0xFF2A2000))),
          if (st == 'pending')
            TextButton(
              onPressed: () async {
                try {
                  await Api.call('/api/orders/${order['id']}/cancel', body: {});
                  await store.refresh();
                } catch (e) {
                  if (context.mounted) toast(context, errMsg(e));
                }
              },
              child: const Text('Cancel order'),
            ),
        ]),
      ),
    );
  }
}

class PinGate extends StatefulWidget {
  final String need;
  final Widget Function() builder;
  const PinGate({super.key, required this.need, required this.builder});
  @override
  State<PinGate> createState() => _PinGateState();
}

class _PinGateState extends State<PinGate> {
  final ctl = TextEditingController();
  bool ok = false, busy = false;

  Future<void> go() async {
    setState(() => busy = true);
    try {
      await Api.call('/api/auth', body: {'pin': ctl.text, 'need': widget.need});
      Api.pin = ctl.text;
      store.refresh();
      if (mounted) setState(() => ok = true);
    } catch (e) {
      if (mounted) toast(context, errMsg(e));
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  void dispose() {
    Api.pin = '';
    ctl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (ok) return widget.builder();
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        TextField(
          controller: ctl,
          obscureText: true,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: 'PIN', border: OutlineInputBorder()),
          onSubmitted: (_) => go(),
        ),
        const SizedBox(height: 12),
        FilledButton(onPressed: busy ? null : go, child: const Padding(padding: EdgeInsets.all(8), child: Text('Sign in'))),
      ]),
    );
  }
}

class StaffPage extends StatelessWidget {
  const StaffPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Staff order board')),
        body: PinGate(need: 'staff', builder: () => const StaffBoard()),
      );
}

Future<void> setStatus(BuildContext c, String id, String st) async {
  try {
    await Api.call('/api/orders/$id/status', body: {'status': st});
    await store.refresh();
  } catch (e) {
    if (c.mounted) toast(c, errMsg(e));
  }
}

class StaffBoard extends StatelessWidget {
  const StaffBoard({super.key});
  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final done = store.orders.where((o) => o['status'] == 'done').toList();
        final sales = done.fold<num>(0, (a, o) => a + ((o['total'] as num?) ?? 0));
        return ListView(padding: const EdgeInsets.all(12), children: [
          Row(children: [
            Expanded(child: stat('Picked up today', '${done.length}')),
            Expanded(child: stat('Sales today', peso(sales))),
          ]),
          for (final f in flow) ...[
            Builder(builder: (_) {
              final os = store.orders.where((o) => o['status'] == f[0]).toList();
              return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Text('${f[1]} (${os.length})', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                ),
                if (os.isEmpty) const Padding(padding: EdgeInsets.only(bottom: 8), child: Text('None')),
                for (final o in os)
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                          Text(tno(o['no'] as int), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                          Text('${o['name'] ?? ''}'),
                        ]),
                        const SizedBox(height: 4),
                        Text(((o['items'] as List?) ?? []).map((i) => '${i['qty']}× ${i['name']}').join('\n')),
                        const SizedBox(height: 8),
                        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                          Text(peso((o['total'] as num?) ?? 0), style: const TextStyle(fontWeight: FontWeight.w700)),
                          Row(children: [
                            if (f[0] != 'ready')
                              TextButton(onPressed: () => setStatus(context, o['id'] as String, 'cancelled'), child: const Text('Cancel')),
                            FilledButton(onPressed: () => setStatus(context, o['id'] as String, f[2]), child: Text(f[3])),
                          ]),
                        ]),
                      ]),
                    ),
                  ),
              ]);
            }),
          ],
        ]);
      },
    );
  }
}

class AdminPage extends StatelessWidget {
  const AdminPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Admin: menu management')),
        body: PinGate(need: 'admin', builder: () => const AdminBody()),
      );
}

class AdminBody extends StatelessWidget {
  const AdminBody({super.key});

  Future<void> addItem(BuildContext context) async {
    final n = TextEditingController(), c = TextEditingController(), p = TextEditingController(), co = TextEditingController(), st = TextEditingController();
    final go = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: const Text('Add menu item'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: n, decoration: const InputDecoration(labelText: 'Name')),
          TextField(controller: c, decoration: const InputDecoration(labelText: 'Category (Rice Meals, Snacks…)')),
          TextField(controller: p, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Price (₱)')),
          TextField(controller: co, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Cost (₱)')),
          TextField(controller: st, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Stock (pieces)')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('Save item')),
        ],
      ),
    );
    if (go != true) return;
    try {
      await Api.call('/api/menu', body: {'name': n.text.trim(), 'cat': c.text.trim(), 'price': double.tryParse(p.text) ?? 0, 'cost': double.tryParse(co.text) ?? 0, 'stock': int.tryParse(st.text) ?? 0});
      await store.refresh();
      if (context.mounted) toast(context, 'Item saved');
    } catch (e) {
      if (context.mounted) toast(context, errMsg(e));
    }
  }

  Future<void> run(BuildContext context, String path, Map<String, dynamic> body) async {
    try {
      await Api.call(path, body: body);
      await store.refresh();
    } catch (e) {
      if (context.mounted) toast(context, errMsg(e));
    }
  }

  Future<void> setStock(BuildContext context, Map<String, dynamic> m) async {
    final ctl = TextEditingController(text: '${m['stock'] ?? 0}');
    final go = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: Text('Stock: ${m['name']}'),
        content: TextField(controller: ctl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Pieces in stock')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('Save')),
        ],
      ),
    );
    if (go == true && context.mounted) run(context, '/api/menu/${m['id']}', {'stock': int.tryParse(ctl.text) ?? 0});
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) => ListView(padding: const EdgeInsets.all(12), children: [
        FilledButton.icon(onPressed: () => addItem(context), icon: const Icon(Icons.add), label: const Text('Add menu item')),
        const SizedBox(height: 8),
        for (final m in store.menu)
          Card(
            child: ListTile(
              title: Text(m['name'] as String),
              onTap: () => setStock(context, m),
              subtitle: Text('${m['cat']} · ${peso(m['price'] as num)} · ${m['stock'] ?? 0} in stock · ${m['on'] == 1 && ((m['stock'] as num?) ?? 0) > 0 ? 'Available' : 'Sold out'}\nTap to change stock'),
              trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                Switch(value: m['on'] == 1, onChanged: (v) => run(context, '/api/menu/${m['id']}', {'on': v ? 1 : 0})),
                IconButton(
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () async {
                    final ok = await showDialog<bool>(
                      context: context,
                      builder: (d) => AlertDialog(
                        title: const Text('Delete this item from the menu?'),
                        actions: [
                          TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Cancel')),
                          FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('Delete')),
                        ],
                      ),
                    );
                    if (ok == true && context.mounted) run(context, '/api/menu/${m['id']}/delete', {});
                  },
                ),
              ]),
            ),
          ),
        const SizedBox(height: 12),
        OutlinedButton(
          onPressed: () async {
            final ok = await showDialog<bool>(
              context: context,
              builder: (d) => AlertDialog(
                title: const Text('Clear today’s orders and restart numbering?'),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(d, false), child: const Text('Cancel')),
                  FilledButton(onPressed: () => Navigator.pop(d, true), child: const Text('Reset queue')),
                ],
              ),
            );
            if (ok == true && context.mounted) run(context, '/api/reset', {});
          },
          child: const Text('Reset today’s queue'),
        ),
      ]),
    );
  }
}
